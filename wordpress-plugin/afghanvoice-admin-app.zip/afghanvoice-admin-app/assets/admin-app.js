(function () {
  'use strict';
  const CFG = window.AVAA || {};
  const root = document.getElementById('avaa-app');
  if (!root) return;
  const S = { page: 'dashboard', data: {}, posts: [], categories: [], users: [], roles: [], menus: [], comments: [], media: [], selectedMenu: 0, search: '', status: 'any', toast: '', loading: false, editingPost: null };
  const asArray = (value) => Array.isArray(value) ? value : [];
  const itemsOf = (value) => Array.isArray(value) ? value : (value && Array.isArray(value.items) ? value.items : []);
  const asObject = (value) => value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  const pashtoError = (error) => {
    const message = String(error && error.message ? error.message : error || '').trim();
    if (message && !/[A-Za-z]{3,}/.test(message)) return message;
    if (/term_exists|already exists|menu name|conflict|duplicate/i.test(message)) return 'د دې نوم لرونکی مینو له مخکې شته؛ مهرباني وکړئ بل نوم وټاکئ.';
    if (/nonce|session|cookie|login|auth|unauthor|forbidden|403/i.test(message)) return 'ستاسې د ننوتلو موده پای ته رسېدلې؛ مهرباني وکړئ بیا ننوځئ.';
    if (/network|fetch|connect|timeout|server|500|502|503/i.test(message)) return 'له سرور سره اړیکه ټینګه نه شوه. انټرنېټ وګورئ او بیا هڅه وکړئ.';
    return 'د غوښتنې پر مهال ستونزه رامنځته شوه. معلومات وګورئ او بیا هڅه وکړئ.';
  };
  let firstLoad = true;
  let appScrollY = 0;
  let appMenuOpen = false;
  let appBodyStyles = null;
  const esc = (v) => String(v == null ? '' : v).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
  const url = (v) => { try { const u = new URL(String(v || ''), location.origin); return ['http:','https:'].includes(u.protocol) ? u.href : '#'; } catch (_) { return '#'; } };
  const endpointUrl = (base, path) => {
    const parts=String(path||'').split('?'); const route=parts[0]||''; const params=new URLSearchParams(parts[1]||''); const u=new URL(base,location.href);
    if (u.searchParams.has('rest_route')) { const baseRoute=u.searchParams.get('rest_route').replace(/\/$/,''); u.searchParams.set('rest_route',baseRoute+'/'+route.replace(/^\//,'')); }
    else { u.pathname=u.pathname.replace(/\/$/,'')+'/'+route.replace(/^\//,''); }
    params.forEach((v,k)=>u.searchParams.set(k,v)); return u.toString();
  };
  const api = async (path, options = {}) => {
    const headers = Object.assign({'X-WP-Nonce': CFG.nonce || ''}, options.headers || {});
    if (options.body && !(options.body instanceof FormData)) headers['Content-Type'] = 'application/json';
    const res = await fetch(endpointUrl(CFG.api || '', path), Object.assign({credentials:'same-origin', headers}, options));
    let json = {}; try { json = await res.json(); } catch (_) {}
    if (!res.ok) throw new Error(pashtoError(json.message || json.code || ''));
    return json;
  };
  const wpApi = async (path, options = {}) => {
    const headers = Object.assign({'X-WP-Nonce': CFG.nonce || ''}, options.headers || {});
    if (options.body && !(options.body instanceof FormData)) headers['Content-Type'] = 'application/json';
    const res = await fetch(endpointUrl(CFG.wpApi || '', path), Object.assign({credentials:'same-origin', headers}, options));
    let json = {}; try { json = await res.json(); } catch (_) {}
    if (!res.ok) throw new Error(pashtoError(json.message || ''));
    return json;
  };
  const toast = (message, bad) => { const el = document.getElementById('avaa-toast'); if (!el) return; el.textContent = bad ? pashtoError(message) : String(message || ''); el.className = 'avaa-toast show' + (bad ? ' bad' : ''); setTimeout(() => el.classList.remove('show'), 3600); };
  const busy = (on) => { S.loading = on; const b = document.querySelector('[data-submit]'); if (b) { b.disabled = on; b.textContent = on ? 'مهرباني، انتظار وکړئ...' : (b.dataset.label || 'خوندي کول'); } };
  const nav = [
    ['dashboard','لنډیز','▦',true], ['posts','خبرونه','▤',true], ['media','انځورونه او فایلونه','▧',!!CFG.canUpload], ['categories','کټګورۍ','▥',!!CFG.canManageCategories], ['menus','مېنو','☷',!!CFG.canManageMenus], ['comments','نظرونه','▱',!!CFG.canModerateComments],
    ['users','کارنان','♙',!!CFG.canManageUsers], ['settings','د وېب‌پاڼې تنظیمات','⚙',!!CFG.canManageSettings]
  ].filter(n=>n[3]);
  function setAppMenu(open) {
    const sidebar = root.querySelector('.avaa-sidebar');
    const backdrop = root.querySelector('.avaa-backdrop');
    const isMobile = window.matchMedia && window.matchMedia('(max-width:760px)').matches;
    open = !!open && !!isMobile;
    if (open === appMenuOpen) return;
    if (open) {
      appScrollY = window.pageYOffset || document.documentElement.scrollTop || 0;
      appBodyStyles = { position: document.body.style.position, top: document.body.style.top, left: document.body.style.left, right: document.body.style.right, width: document.body.style.width };
      document.body.style.position = 'fixed'; document.body.style.top = '-' + appScrollY + 'px'; document.body.style.left = '0'; document.body.style.right = '0'; document.body.style.width = '100%';
      document.documentElement.classList.add('avaa-menu-locked'); document.body.classList.add('avaa-menu-locked');
    } else {
      document.documentElement.classList.remove('avaa-menu-locked'); document.body.classList.remove('avaa-menu-locked');
      if (appBodyStyles) { Object.keys(appBodyStyles).forEach((key) => { document.body.style[key] = appBodyStyles[key]; }); }
      window.scrollTo(0, appScrollY); appBodyStyles = null;
    }
    appMenuOpen = open;
    if (sidebar) sidebar.classList.toggle('open', open);
    if (backdrop) backdrop.classList.toggle('active', open);
    const button = root.querySelector('#avaa-menu-toggle'); if (button) button.setAttribute('aria-expanded', open ? 'true' : 'false');
  }
  function shell(content) {
    if (appMenuOpen) setAppMenu(false);
    root.innerHTML = `<div class="avaa-backdrop" id="avaa-backdrop" aria-hidden="true"></div><div class="avaa-shell"><aside class="avaa-sidebar"><div class="avaa-brand">${CFG.logo ? `<img src="${esc(url(CFG.logo))}" alt="افغان غږ">` : '<b>افغان غږ</b>'}<span>د ادارې اپ</span></div><div class="avaa-user"><span class="avaa-avatar">${esc((CFG.user?.name || 'ا').slice(0,1))}</span><div><b>${esc(CFG.user?.name || 'مدیر')}</b><small>مدیریتي حساب</small></div></div><nav>${nav.map(n=>`<button class="avaa-nav ${S.page===n[0]?'active':''}" data-page="${n[0]}"><span>${n[2]}</span>${n[1]}</button>`).join('')}</nav><a class="avaa-home-link" href="${esc(url(CFG.home))}" target="_blank" rel="noopener">↗ د وېب‌پاڼې لیدل</a><button class="avaa-logout" id="avaa-logout">وتل</button></aside><main class="avaa-main"><header class="avaa-topbar"><button class="avaa-menu-toggle" id="avaa-menu-toggle" aria-label="مینو">☰</button><div><strong>افغان غږ</strong><small>د خبرونو او وېب‌پاڼې اداره</small></div><div class="avaa-top-actions"><span class="avaa-online"><i></i> نښلول شوی</span><button class="avaa-install-btn" id="avaa-install">اپ نصب کړئ</button><a href="${esc(url(CFG.home))}" target="_blank" rel="noopener">وېب‌پاڼه ↗</a></div></header><section class="avaa-content">${content}</section><footer class="avaa-footer">افغان غږ · د ادارې اپ · نسخه ${esc(CFG.version || '')}</footer></main></div><div class="avaa-toast" id="avaa-toast" role="status"></div>`;
  }
  const pageTitle = (title, subtitle, action='') => `<div class="avaa-page-head"><div><h1>${title}</h1><p>${subtitle || ''}</p></div>${action}</div>`;
  function loadingPage() { if (firstLoad) { firstLoad = false; return; } shell('<div class="avaa-empty"><div class="avaa-spinner"></div><p>معلومات ترلاسه کېږي...</p></div>'); }
  async function refreshDashboard() { S.data = asObject(await api('/dashboard')); S.data.recent = asArray(S.data.recent); }
  async function loadPosts() { const q = new URLSearchParams({per_page:'30',page:'1',status:S.status,search:S.search}); const d=await api('/posts?'+q.toString()); S.posts=itemsOf(d); S.posts=S.posts.map(p=>({...asObject(p),categories:asArray(p && p.categories)})); }
  async function loadCategories() { S.categories=itemsOf(await api('/categories')); }
  async function loadUsers() { const d=asObject(await api('/users')); S.users=asArray(d.items).map(u=>({...asObject(u),roles:asArray(u && u.roles)})); S.roles=asArray(d.roles); }
  async function loadMenus() { const d=asObject(await api('/menus')); S.menus=asArray(d.items).map(m=>({...asObject(m),items:asArray(m && m.items),locations:asArray(m && m.locations)})); S.menuLocations=asObject(d.locations); if (!S.selectedMenu && S.menus[0]) S.selectedMenu=S.menus[0].id; }
  async function loadComments() { S.comments=itemsOf(await api('/comments?status=all')); }
  async function loadSettings() { const d=asObject(await api('/settings')); S.settings={...d,categories:asArray(d.categories),home_sections:asObject(d.home_sections)}; }
  async function loadMedia() { S.media=itemsOf(await wpApi('/media?per_page=30&media_type=image')); }
  const stat = (label, value, color, hint) => `<div class="avaa-stat"><span class="stat-icon ${color}">${hint||'•'}</span><div><small>${label}</small><b>${value}</b></div></div>`;
  async function renderDashboard() {
    loadingPage(); await refreshDashboard(); const d=asObject(S.data); const postCounts=asObject(d.posts); const commentCounts=asObject(d.comments); const recent=asArray(d.recent);
    const cards = recent.map((p) => {
      p=asObject(p); const cats=asArray(p.categories); const categoryNames=cats.map(c=>esc(asObject(c).name)).filter(Boolean).join('، ');
      const imageUrl=p.featured_image ? esc(url(p.featured_image)) : '';
      const image=imageUrl ? `<img src="${imageUrl}" alt="${esc(p.title||'د خبر انځور')}" loading="lazy">` : '<span class="avaa-news-placeholder" aria-hidden="true">افغان غږ</span>';
      return `<article class="avaa-news-card"><a class="avaa-news-image" href="${esc(url(p.url||''))}" target="_blank" rel="noopener">${image}</a><div class="avaa-news-body"><div class="avaa-news-meta"><span class="avaa-news-category">${categoryNames || 'بې کټګورۍ'}</span><time>${esc(p.date||'')}</time></div><h3><a href="${esc(url(p.url||''))}" target="_blank" rel="noopener">${esc(p.title||'بې‌سرلیکه خبر')}</a></h3><div class="avaa-news-byline"><span>لیکوال: ${esc(p.author||'نامعلوم')}</span>${statusLabel(p.status||'draft')}</div><div class="avaa-news-actions"><button class="avaa-small-btn" data-edit-post="${Number(p.id)||0}">سمول</button><a class="avaa-small-btn" href="${esc(url(p.url||''))}" target="_blank" rel="noopener">خبر کتل ↗</a></div></div></article>`;
    }).join('');
    shell(`${pageTitle('د ادارې لنډیز',`ښه راغلاست، ${esc(d.user||'')}. د وېب‌پاڼې اوسنی وضعیت دلته وګورئ.`,`<button class="avaa-btn primary" data-action="new-post">＋ نوی خبر</button>`)}<div class="avaa-stats">${stat('خپاره شوي خبرونه',postCounts.published||0,'blue','▤')}${stat('مسودې',postCounts.draft||0,'gold','✎')}${stat('د تایید په تمه',postCounts.pending||0,'purple','◷')}${stat('کټګورۍ',d.categories||0,'green','▥')}${CFG.canManageUsers?stat('کارنان',d.users||0,'blue','♙'):''}${stat('ناکتل شوي نظرونه',commentCounts.moderated||0,'red','▱')}</div><div class="avaa-panel"><div class="avaa-panel-head"><div><h2>وروستي خبرونه</h2><p>د وېب‌پاڼې وروستي ثبت شوي خبرونه</p></div><button class="avaa-link-btn" data-page="posts">ټول خبرونه ←</button></div>${cards?`<div class="avaa-news-grid">${cards}</div>`:'<div class="avaa-empty">تر اوسه خبرونه نشته.</div>'}</div><div class="avaa-quick-grid"><button class="avaa-quick" data-action="new-post"><b>＋</b><span>خبر خپور کړئ</span></button><button class="avaa-quick" data-page="categories"><b>▥</b><span>کټګورۍ اداره کړئ</span></button><button class="avaa-quick" data-page="menus"><b>☷</b><span>مېنو تنظیم کړئ</span></button><button class="avaa-quick" data-page="settings"><b>⚙</b><span>تنظیمات</span></button></div>`);
  }
  function statusLabel(s) { const m={publish:'خپور شوی',draft:'مسوده',pending:'د تایید په تمه',private:'شخصي',future:'مهالوېش شوی',trash:'کثافت دانۍ'};return `<span class="avaa-status ${esc(s)}">${m[s]||esc(s)}</span>`; }
  function postEditor(p) {
    const cats=asArray(S.categories); return `${pageTitle(p?'خبر سمول':'نوی خبر', 'د خبر معلومات ولیکئ او په وېب‌پاڼه کې یې خپاره کړئ.')}<form id="avaa-post-form" class="avaa-panel avaa-form"><input type="hidden" name="id" value="${p?.id||''}"><div class="avaa-form-grid"><label class="wide">د خبر سرلیک *<input name="title" required maxlength="250" value="${esc(p?.title||'')}" placeholder="د خبر سرلیک ولیکئ"></label><label class="wide">د خبر متن *<textarea name="content" required rows="11" placeholder="د خبر بشپړ متن ولیکئ...">${esc(p?.content||'')}</textarea></label><label>کټګوري<select name="category"><option value="0">کټګوري وټاکئ</option>${cats.map(c=>`<option value="${c.id}" ${asArray(p?.categories).some(x=>Number(asObject(x).id)===Number(c.id))?'selected':''}>${esc(c.name)}</option>`).join('')}</select></label><label>د خپرېدو حالت<select name="status"><option value="publish" ${p?.status==='publish'?'selected':''}>خپرول</option><option value="draft" ${!p||p.status==='draft'?'selected':''}>مسوده</option><option value="pending" ${p?.status==='pending'?'selected':''}>د تایید په تمه</option></select></label><label class="wide">د خبر انځور<input type="file" name="image" accept="image/jpeg,image/png,image/webp"><small>JPG، PNG یا WebP؛ تر ۱۰ MB پورې.</small>${p?.featured_image?`<img class="avaa-editor-image" src="${esc(url(p.featured_image))}" alt="اوسنی انځور">`:''}</label><label class="wide">د ویډیو لینک (YouTube)<input name="video" type="url" dir="ltr" value="${esc(p?.video||'')}" placeholder="https://www.youtube.com/watch?v=..."></label></div><div class="avaa-checks"><label><input type="checkbox" name="featured" ${p?.featured?'checked':''}> مهم خبر</label><label><input type="checkbox" name="breaking" ${p?.breaking?'checked':''}> بېړنی خبر</label></div><div class="avaa-form-actions"><button class="avaa-btn primary" type="submit" data-submit data-label="${p?'بدلونونه خوندي کړئ':'خبر خوندي کړئ'}">${p?'بدلونونه خوندي کړئ':'خبر خوندي کړئ'}</button><button type="button" class="avaa-btn light" data-page="posts">بېرته</button></div></form>`;
  }
  async function renderPosts() {
    loadingPage(); await Promise.all([loadPosts(),loadCategories()]);
    const rows=asArray(S.posts).map(p=>`<tr><td><b>${esc(p.title)}</b><small class="row-sub">${esc(p.author)} · ${esc(asArray(p.categories).map(c=>asObject(c).name).filter(Boolean).join('، '))}</small></td><td>${statusLabel(p.status)}</td><td>${esc(p.date)}</td><td><div class="row-actions"><button class="avaa-small-btn" data-edit-post="${p.id}">سمول</button><button class="avaa-small-btn danger" data-delete-post="${p.id}">حذف</button></div></td></tr>`).join('');
    shell(`${pageTitle('خبرونه','خبرونه خپاره، سم او حذف کړئ.','<button class="avaa-btn primary" data-action="new-post">＋ نوی خبر</button>')}<div class="avaa-toolbar"><input id="avaa-post-search" value="${esc(S.search)}" placeholder="خبر ولټوئ..."><select id="avaa-post-status"><option value="any">ټول حالتونه</option><option value="publish" ${S.status==='publish'?'selected':''}>خپاره شوي</option><option value="draft" ${S.status==='draft'?'selected':''}>مسودې</option><option value="pending" ${S.status==='pending'?'selected':''}>د تایید په تمه</option></select><button class="avaa-btn light" data-action="search-posts">لټون</button></div><div class="avaa-panel"><div class="avaa-table-wrap"><table><thead><tr><th>خبر</th><th>حالت</th><th>نېټه</th><th>عمل</th></tr></thead><tbody>${rows||'<tr><td colspan="4">خبر ونه موندل شو.</td></tr>'}</tbody></table></div></div>`);
  }
  async function renderCategories() {
    loadingPage(); await loadCategories();
    shell(`${pageTitle('کټګورۍ','کټګورۍ جوړې او تنظیم کړئ.')}<form id="avaa-category-form" class="avaa-panel avaa-inline-form"><input type="hidden" name="id"><label>نوم<input name="name" required placeholder="د کټګورۍ نوم"></label><label>Slug<input name="slug" dir="ltr" placeholder="category-name"></label><label>اصلي کټګوري<select name="parent"><option value="0">اصلي کټګوري</option>${asArray(S.categories).map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join('')}</select></label><button class="avaa-btn primary" type="submit" data-submit data-label="کټګوري جوړول">کټګوري جوړول</button></form><div class="avaa-panel"><div class="avaa-list">${asArray(S.categories).map(c=>`<div class="avaa-list-row"><div><b>${esc(c.name)}</b><small dir="ltr">${esc(c.slug)} · ${c.count} خبرونه</small></div><div><button class="avaa-small-btn" data-edit-cat="${c.id}">سمول</button><button class="avaa-small-btn danger" data-delete-cat="${c.id}">حذف</button></div></div>`).join('')}</div></div>`);
  }
  async function renderUsers() {
    loadingPage(); await loadUsers();
    shell(`${pageTitle('کارنان','د مدیرانو، لیکوالانو او نورو کارنانو حسابونه اداره کړئ.')}<form id="avaa-user-form" class="avaa-panel avaa-form"><h2>نوی کارن جوړول</h2><div class="avaa-form-grid"><label>کارن نوم *<input name="username" required autocomplete="off"></label><label>ښکاره نوم<input name="name"></label><label>ایمیل *<input type="email" name="email" required dir="ltr"></label><label>پټنوم *<input type="password" name="password" required minlength="12" autocomplete="new-password"><small>لږ تر لږه ۱۲ توري.</small></label>${CFG.canPromoteUsers?`<label>رول<select name="role">${asArray(S.roles).map(r=>`<option value="${esc(r.key)}" ${r.key===(CFG.defaultRole||'subscriber')?'selected':''}>${esc(r.name)}</option>`).join('')}</select></label>`:'<input type="hidden" name="role" value="">'}</div><button class="avaa-btn primary" type="submit" data-submit data-label="کارن جوړول">کارن جوړول</button></form><div class="avaa-panel"><div class="avaa-table-wrap"><table><thead><tr><th>کارن</th><th>ایمیل</th><th>رول</th><th>عمل</th></tr></thead><tbody>${asArray(S.users).map(u=>`<tr><td><b>${esc(u.name)}</b><small class="row-sub">${esc(u.username)}</small></td><td dir="ltr">${esc(u.email)}</td><td>${asArray(u.roles).map(esc).join('، ')}</td><td>${u.id!==CFG.user?.id?`<button class="avaa-small-btn" data-edit-user="${u.id}">رول بدلول</button><button class="avaa-small-btn danger" data-delete-user="${u.id}">حذف</button>`:'اوسنی حساب'}</td></tr>`).join('')}</tbody></table></div></div>`);
  }
  async function renderMenus() {
    loadingPage(); await Promise.all([loadMenus(),loadCategories()]); const menu=S.menus.find(m=>m.id===Number(S.selectedMenu))||S.menus[0]; if(menu) S.selectedMenu=menu.id;
    shell(`${pageTitle('مېنو','اصلي او فرعي لینکونه جوړ، بدل او د قالب مینو ته وصل کړئ.')}<div class="avaa-panel"><form id="avaa-menu-create" class="avaa-inline-form"><label>نوی مینو<input name="name" placeholder="د مینو نوم"></label><label>د قالب ځای<select name="location"><option value="primary">اصلي مینو</option><option value="footer">لاندې مینو</option></select></label><button class="avaa-btn primary" type="submit" data-submit data-label="مینو جوړول">مینو جوړول</button></form></div>${S.menus.length?`<div class="avaa-panel"><div class="avaa-menu-select-row"><label class="avaa-field-label">موجود مینو<select id="avaa-menu-select">${asArray(S.menus).map(m=>`<option value="${m.id}" ${m.id===S.selectedMenu?'selected':''}>${esc(m.name)} ${m.locations.length?'(فعال)':''}</option>`).join('')}</select></label><div><button class="avaa-small-btn" data-rename-menu="${menu?.id||''}">نوم بدلول</button><button class="avaa-small-btn danger" data-delete-menu="${menu?.id||''}">مینو حذف</button></div></div><form id="avaa-menu-item-form" class="avaa-inline-form"><input type="hidden" name="menu_id" value="${menu?.id||''}"><label>د لینک نوم<input name="title" required></label><label>د لینک ډول<select name="type" id="avaa-menu-type"><option value="category">کټګوري</option><option value="custom">بهرنی/ځانګړی لینک</option></select></label><label id="avaa-menu-cat-wrap">کټګوري<select name="object_id">${asArray(S.categories).map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join('')}</select></label><label id="avaa-menu-url-wrap" hidden>URL<input name="url" dir="ltr" placeholder="https://..."></label><label>د والد توکی<select name="parent"><option value="0">اصلي توکی</option>${(menu?.items||[]).map(i=>`<option value="${i.id}">${esc(i.title)}</option>`).join('')}</select></label><label>ترتیب<input type="number" name="position" min="0" value="${(menu?.items||[]).length+1}"></label><button class="avaa-btn primary" type="submit" data-submit data-label="لینک اضافه کول">لینک اضافه کول</button></form><div class="avaa-list">${(menu?.items||[]).map((i,index)=>`<div class="avaa-list-row ${i.parent?'menu-child':''}"><div><b>${esc(i.title)}</b><small dir="ltr">${esc(i.url)}</small></div><div><button class="avaa-small-btn" data-edit-menu-item="${i.id}">سمول</button><button class="avaa-small-btn" data-move-menu-item="${i.id}" data-direction="up" ${index===0?'disabled':''}>↑</button><button class="avaa-small-btn" data-move-menu-item="${i.id}" data-direction="down" ${index===menu.items.length-1?'disabled':''}>↓</button><button class="avaa-small-btn danger" data-delete-menu-item="${i.id}">لرې کول</button></div></div>`).join('')||'<p>په دې مینو کې توکي نشته.</p>'}</div></div>`:'<div class="avaa-empty">تر اوسه مینو نه دی جوړ شوی.</div>'}`);
  }
  async function renderComments() {
    loadingPage(); await loadComments();
    shell(`${pageTitle('نظرونه','د لوستونکو نظرونه تایید، سپم یا حذف کړئ.')}<div class="avaa-panel"><div class="avaa-list">${asArray(S.comments).map(c=>`<div class="avaa-comment"><div><b>${esc(c.author)}</b><small>${esc(c.post)} · ${esc(c.date)}</small><p>${esc(c.content)}</p></div><div class="row-actions"><button class="avaa-small-btn" data-comment="${c.id}" data-status="approve">تایید</button><button class="avaa-small-btn" data-comment="${c.id}" data-status="spam">سپم</button><button class="avaa-small-btn danger" data-delete-comment="${c.id}">حذف</button></div></div>`).join('')||'<div class="avaa-empty">نظرونه نشته.</div>'}</div></div>`);
  }
  async function renderMedia() {
    loadingPage(); await loadMedia();
    shell(`${pageTitle('انځورونه او فایلونه','انځورونه WordPress ته پورته او د رسنیو کتابتون کې یې اداره کړئ.')}<form id="avaa-media-form" class="avaa-panel avaa-form"><label>انځور وټاکئ<input type="file" name="file" accept="image/jpeg,image/png,image/webp" required><small>د هر فایل حد ۱۰ MB دی. ویډیو د YouTube لینک له لارې ثبتېږي.</small></label><button class="avaa-btn primary" type="submit" data-submit data-label="انځور پورته کول">انځور پورته کول</button></form><div class="avaa-media-grid">${asArray(S.media).map(m=>`<div class="avaa-media-card"><img src="${esc(url(m.media_details?.sizes?.medium?.source_url||m.source_url))}" alt="${esc(m.alt_text||m.slug)}"><span>${esc(m.title?.rendered||'انځور')}</span><button class="avaa-small-btn" data-copy-url="${esc(m.source_url)}">لینک کاپي</button><button class="avaa-small-btn" data-set-logo="${m.id}">د وېب‌پاڼې لوګو وټاکئ</button><button class="avaa-small-btn danger" data-delete-media="${m.id}">حذف</button></div>`).join('')||'<p>انځورونه نشته.</p>'}</div>`);
  }
  async function renderSettings() {
    loadingPage(); await loadSettings(); const d=S.settings;
    const field=(label,key,type='text',dir='')=>`<label>${label}<input name="${key}" type="${type}" ${dir?'dir="'+dir+'"':''} value="${esc(d[key]||'')}"></label>`;
    const selectCats=(label,key)=>`<label>${label}<select name="${key}"><option value="0">کټګوري وټاکئ</option>${asArray(d.categories).map(c=>`<option value="${c.id}" ${asArray(d.home_sections?.[key]).includes(c.id)?'selected':''}>${esc(c.name)}</option>`).join('')}</select></label>`;
    shell(`${pageTitle('د وېب‌پاڼې تنظیمات','د افغان غږ نوم، راډیو، PDF، هوا، اسعار، ټولنیزې رسنۍ او کورپاڼه تنظیم کړئ.')}<form id="avaa-settings-form" class="avaa-panel avaa-form"><h2>عمومي معلومات</h2><div class="avaa-form-grid">${CFG.canManageSite?field('د وېب‌پاڼې نوم','site_title')+field('لنډه پېژندنه','site_description'):'<p class="avaa-help">د وېب‌پاڼې د نوم بدلول یوازې د عمومي مدیر اجازه لري.</p>'}</div><h2>راډیو او اوونیزه</h2><div class="avaa-form-grid">${field('د راډیو نوم','radio_title')}${field('د راډیو Stream URL','radio_url','url','ltr')}${field('د اوونیزې نوم','weekly_title')}${field('د PDF لینک','weekly_url','url','ltr')}${field('د اوونیزې د پوښ لینک','weekly_cover','url','ltr')}</div><h2>هوا</h2><div class="avaa-form-grid">${field('ښار','weather_city')}${field('Latitude','weather_lat','text','ltr')}${field('Longitude','weather_lon','text','ltr')}<label class="check-label"><input type="checkbox" name="weather_enabled" ${d.weather_enabled!=='0'?'checked':''}> د هوا برخه فعاله</label></div><h2>اسعار</h2><div class="avaa-form-grid">${['usd','eur','pkr','sar','aed'].map(k=>field(k.toUpperCase()+' - اخیستل',k+'_buy')).join('')}${['usd','eur','pkr','sar','aed'].map(k=>field(k.toUpperCase()+' - پلورل',k+'_sell')).join('')}</div><h2>ټولنیزې رسنۍ</h2><div class="avaa-form-grid">${field('Facebook','facebook_url','url','ltr')}${field('X','x_url','url','ltr')}${field('YouTube','youtube_url','url','ltr')}${field('Instagram','instagram_url','url','ltr')}${field('Telegram','telegram_url','url','ltr')}</div><h2>فوټر او ژباړه</h2><div class="avaa-form-grid">${field('د فوټر پېژندنه','footer_about')}${field('د فوټر اضافي متن','footer_note')}<label class="check-label"><input type="checkbox" name="auto_translate" ${d.auto_translate!=='0'?'checked':''}> د اتومات ژباړې اختیار</label></div><h2>د کورپاڼې کټګورۍ</h2><p class="avaa-help">هره خبري برخه له خپلې موجودې کټګورۍ سره وتړئ. د پخوانیو کټګوریو لینکونه نه بدلېږي.</p><div class="avaa-form-grid">${[['afghanistan','افغانستان'],['region','سیمه'],['world','نړۍ'],['politics','سیاست'],['economy','سوداګري او اقتصاد'],['reconstruction','بیارغونه او پراختیا'],['reports','راپورونه'],['analysis','تبصرې او تحلیلونه'],['editorials','سرمقاله'],['photos','انځورونه'],['health','روغتیا'],['culture','اسلام او کلتور'],['sports','لوبې'],['technology','ټکنالوژي'],['articles','مقالات'],['documentaries','مستند فلمونه'],['video_news','ویډیوګانې'],['radio_news','راډیويي خپرونې']].map(([k,l])=>selectCats(l,k)).join('')}</div><h2>مینو</h2><label>د مینو بڼه<select name="menu_mode"><option value="auto" ${d.menu_mode!=='wordpress'?'selected':''}>اتومات کټګورۍ مینو</option><option value="wordpress" ${d.menu_mode==='wordpress'?'selected':''}>لاس جوړ WordPress مینو</option></select></label><div class="avaa-form-actions"><button class="avaa-btn primary" type="submit" data-submit data-label="تنظیمات خوندي کول">تنظیمات خوندي کول</button></div></form><div class="avaa-panel"><h2>پرمختللي WordPress تنظیمات</h2><p>د لوګو، امنیت، Permalink او نورو اصلي WordPress تنظیماتو لپاره لاندې اصلي اداره پرانیزئ.</p><a class="avaa-btn light" href="${esc(url(CFG.home+'wp-admin/customize.php'))}" target="_blank" rel="noopener">د قالب تنظیمات ↗</a> <a class="avaa-btn light" href="${esc(url(CFG.home+'wp-admin/options-general.php'))}" target="_blank" rel="noopener">عمومي تنظیمات ↗</a></div>`);
  }
  async function render() {
    try {
      switch (S.page) {
        case 'dashboard': return await renderDashboard(); case 'posts': return await renderPosts(); case 'post-editor': return shell(postEditor(S.editingPost));
        case 'categories': return await renderCategories(); case 'users': return await renderUsers(); case 'menus': return await renderMenus(); case 'comments': return await renderComments(); case 'media': return await renderMedia(); case 'settings': return await renderSettings(); default: S.page='dashboard'; return await renderDashboard();
      }
    } catch (e) { shell(`${pageTitle('ستونزه','د معلوماتو ترلاسه کولو پر مهال ستونزه پېښه شوه.')}<div class="avaa-panel avaa-error">${esc(pashtoError(e))}</div><button class="avaa-btn primary" data-action="reload">بیا هڅه</button>`); }
  }
  function go(page) { S.page=page; S.editingPost=null; render(); }
  async function uploadFile(file) {
    const fd=new FormData(); fd.append('file',file); return api('/upload',{method:'POST',body:fd});
  }
  root.addEventListener('click', async (e) => {
    const target=e.target.closest('[data-page],[data-action],[data-edit-post],[data-delete-post],[data-edit-cat],[data-delete-cat],[data-delete-user],[data-edit-user],[data-comment],[data-delete-comment],[data-delete-menu-item],[data-copy-url],[data-set-logo],[data-delete-media],[data-rename-menu],[data-delete-menu],[data-edit-menu-item],[data-move-menu-item]');
    if (!target) return;
    if (target.dataset.page) { setAppMenu(false); S.page=target.dataset.page; await render(); return; }
    if (target.dataset.action==='new-post') { await loadCategories(); S.editingPost=null; S.page='post-editor'; await render(); return; }
    if (target.dataset.action==='reload') { await render(); return; }
    try {
      if (target.dataset.editPost) { S.editingPost=await api('/posts/'+target.dataset.editPost); S.page='post-editor'; await loadCategories(); await render(); }
      else if (target.dataset.deletePost && confirm('دا خبر کثافت دانۍ ته ولېږدول شي؟')) { await api('/posts/'+target.dataset.deletePost,{method:'DELETE'}); toast('خبر کثافت دانۍ ته ولېږدول شو.'); await renderPosts(); }
      else if (target.dataset.editCat) { const c=asArray(S.categories).find(x=>x.id===Number(target.dataset.editCat)); const f=document.getElementById('avaa-category-form'); f.elements.id.value=c.id; f.elements.name.value=c.name; f.elements.slug.value=c.slug; f.elements.parent.value=c.parent; f.querySelector('[data-submit]').textContent='کټګوري اصلاح کول'; f.scrollIntoView({behavior:'smooth'}); }
      else if (target.dataset.deleteCat && confirm('کټګوري حذف شي؟ پوسټونه به د WordPress اصلي کټګورۍ ته ولېږدول شي.')) { await api('/categories/'+target.dataset.deleteCat,{method:'DELETE'}); toast('کټګوري حذف شوه.'); await renderCategories(); }
      else if (target.dataset.deleteUser && confirm('دا کارن حذف شي؟ د هغه لیکنې به د اوسني کارن حساب ته منسوب شي.')) { await api('/users/'+target.dataset.deleteUser,{method:'DELETE'}); toast('کارن حذف شو.'); await renderUsers(); }
      else if (target.dataset.editUser) { if(!CFG.canPromoteUsers){toast('د کارن د رول بدلولو اجازه نه لرئ.',true);return;} const u=asArray(S.users).find(x=>x.id===Number(target.dataset.editUser)); if(!u) return; const name=prompt('د کارن ښکاره نوم:',u.name); if(name===null)return; const email=prompt('د کارن ایمیل:',u.email); if(email===null)return; const role=prompt('نوی رول ('+asArray(S.roles).map(r=>r.key).join('، ')+'):',u.roles?.[0]||'subscriber'); if(role===null)return; const password=prompt('نوی پټنوم (اختیاري؛ تش پرېږدئ چې بدل نه شي):',''); const payload={name,email,role}; if(password)payload.password=password; await api('/users/'+u.id,{method:'POST',body:JSON.stringify(payload)});toast('د کارن معلومات اصلاح شول.');await renderUsers(); }
      else if (target.dataset.comment) { await api('/comments/'+target.dataset.comment,{method:'POST',body:JSON.stringify({status:target.dataset.status})}); toast('د نظر حالت بدل شو.'); await renderComments(); }
      else if (target.dataset.deleteComment && confirm('نظر حذف شي؟')) { await api('/comments/'+target.dataset.deleteComment,{method:'DELETE'}); toast('نظر حذف شو.'); await renderComments(); }
      else if (target.dataset.deleteMenuItem && confirm('دا لینک له مینو لرې شي؟')) { await api('/menu-items/'+target.dataset.deleteMenuItem,{method:'DELETE'}); toast('د مینو لینک لرې شو.'); await renderMenus(); }
      else if (target.dataset.renameMenu) { const menu=asArray(S.menus).find(m=>m.id===Number(target.dataset.renameMenu)); const name=prompt('د مینو نوی نوم:',menu?.name||''); if(name){await api('/menus/'+menu.id,{method:'POST',body:JSON.stringify({name})});toast('د مینو نوم بدل شو.');await renderMenus();} }
      else if (target.dataset.deleteMenu && confirm('ټاکل شوی مینو حذف شي؟')) { await api('/menus/'+target.dataset.deleteMenu,{method:'DELETE'}); S.selectedMenu=0; toast('مینو حذف شو.'); await renderMenus(); }
      else if (target.dataset.editMenuItem) { const menu=asArray(S.menus).find(m=>m.id===S.selectedMenu); const item=asArray(menu?.items).find(i=>i.id===Number(target.dataset.editMenuItem)); if(item){const title=prompt('د مینو د لینک نوم:',item.title);if(title!==null){const payload={menu_id:menu.id,title,type:item.type,parent:item.parent,position:item.order};if(item.type==='category')payload.object_id=item.object_id;else payload.url=item.url;await api('/menu-items/'+item.id,{method:'POST',body:JSON.stringify(payload)});toast('د مینو لینک اصلاح شو.');await renderMenus();}} }
      else if (target.dataset.moveMenuItem) { const menu=asArray(S.menus).find(m=>m.id===S.selectedMenu); const list=asArray(menu?.items); const idx=list.findIndex(i=>i.id===Number(target.dataset.moveMenuItem)); const next=target.dataset.direction==='up'?idx-1:idx+1; if(idx>=0&&next>=0&&next<list.length){const a=list[idx],b=list[next]; const update=async(i,pos)=>{const d={menu_id:menu.id,title:i.title,type:i.type,parent:i.parent,position:pos};if(i.type==='category')d.object_id=i.object_id;else d.url=i.url;return api('/menu-items/'+i.id,{method:'POST',body:JSON.stringify(d)});};await update(a,b.order);await update(b,a.order);toast('د مینو ترتیب بدل شو.');await renderMenus();} }
      else if (target.dataset.copyUrl) { await navigator.clipboard.writeText(target.dataset.copyUrl); toast('لینک کاپي شو.'); }
      else if (target.dataset.setLogo) { await api('/branding',{method:'POST',body:JSON.stringify({attachment_id:Number(target.dataset.setLogo)})}); toast('د وېب‌پاڼې لوګو بدل شو.'); }
      else if (target.dataset.deleteMedia && confirm('دا انځور د رسنیو له کتابتون څخه د تل لپاره حذف شي؟')) { await api('/media/'+target.dataset.deleteMedia,{method:'DELETE'}); toast('انځور حذف شو.'); await renderMedia(); }
    } catch(err){toast(pashtoError(err),true);}
  });
  root.addEventListener('submit', async (e) => {
    const form=e.target; e.preventDefault(); busy(true);
    try {
      if (form.id==='avaa-post-form') {
        const fd=new FormData(form); let thumbnail=Number(S.editingPost?.thumbnail_id||0); const file=fd.get('image'); if(file && file.size){if(file.size>10*1024*1024) throw new Error('د انځور اندازه باید تر ۱۰ MB کمه وي.');const uploaded=await uploadFile(file);thumbnail=uploaded.id;}
        const data={title:fd.get('title'),content:fd.get('content'),category:Number(fd.get('category')),status:fd.get('status'),featured:fd.has('featured'),breaking:fd.has('breaking'),video:fd.get('video'),thumbnail_id:thumbnail};
        const id=fd.get('id'); const result=await api('/posts'+(id?'/'+id:''),{method:'POST',body:JSON.stringify(data)}); toast(result.message); S.page='posts'; await renderPosts();
      } else if (form.id==='avaa-category-form') {
        const fd=new FormData(form); const id=fd.get('id'); const data={name:fd.get('name'),slug:fd.get('slug'),parent:Number(fd.get('parent'))}; await api('/categories'+(id?'/'+id:''),{method:'POST',body:JSON.stringify(data)}); toast('کټګوري خوندي شوه.'); await renderCategories();
      } else if (form.id==='avaa-user-form') {
        const fd=new FormData(form); await api('/users',{method:'POST',body:JSON.stringify(Object.fromEntries(fd.entries()))}); toast('نوی کارن جوړ شو.'); await renderUsers();
      } else if (form.id==='avaa-menu-create') {
        const fd=new FormData(form); const r=await api('/menus',{method:'POST',body:JSON.stringify({name:fd.get('name'),location:fd.get('location')})}); S.selectedMenu=r.id; toast('مینو جوړ شو.'); await renderMenus();
      } else if (form.id==='avaa-menu-item-form') {
        const fd=new FormData(form); await api('/menu-items',{method:'POST',body:JSON.stringify(Object.fromEntries(fd.entries()))}); toast('لینک مینو ته اضافه شو.'); await renderMenus();
      } else if (form.id==='avaa-media-form') {
        const fd=new FormData(form); const file=fd.get('file'); if(!file || !file.size) throw new Error('انځور وټاکئ.'); const r=await uploadFile(file); toast('انځور پورته شو.'); await renderMedia();
      } else if (form.id==='avaa-settings-form') {
        const fd=new FormData(form); const data={}; for(const [k,v] of fd.entries()) data[k]=v; ['weather_enabled','auto_translate'].forEach(k=>data[k]=form.elements[k].checked);
        ['afghanistan','region','world','politics','economy','reconstruction','reports','analysis','editorials','photos','health','culture','sports','technology','articles','documentaries','video_news','radio_news'].forEach(k=>{const v=Number(fd.get(k)||0);data.home_sections={...(data.home_sections||{}),[k]:v?[v]:[]};});
        await api('/settings',{method:'POST',body:JSON.stringify(data)}); toast('تنظیمات خوندي شول.'); await renderSettings();
      }
    } catch(err){toast(pashtoError(err),true);} finally {busy(false);}
  });
  root.addEventListener('click', async (e) => {
    if (e.target.id==='avaa-install') {
      if (window.AVAAInstallPrompt) { window.AVAAInstallPrompt.prompt(); try { await window.AVAAInstallPrompt.userChoice; } catch (_) {} window.AVAAInstallPrompt=null; }
      else if (/iphone|ipad|ipod/i.test(navigator.userAgent)) alert('په Safari کې Share تڼۍ کېکاږئ، بیا Add to Home Screen وټاکئ.');
      else alert('د براوزر له مېنو څخه Install App یا Add to Home Screen وټاکئ. د اپ نصب لپاره HTTPS اړین دی.');
    }
    if (e.target.id==='avaa-menu-toggle') { setAppMenu(!appMenuOpen); return; }
    if (e.target.id==='avaa-backdrop') { setAppMenu(false); return; }
    if (e.target.id==='avaa-logout') { if(confirm('له WordPress څخه ووځئ؟')) location.href=url(CFG.logout || CFG.home+'wp-login.php'); }
    if (e.target.closest('.avaa-nav')) setAppMenu(false);
  });
  root.addEventListener('change', (e) => {
    if(e.target.id==='avaa-menu-select'){S.selectedMenu=Number(e.target.value);renderMenus();}
    if(e.target.id==='avaa-menu-type'){const isCat=e.target.value==='category';document.getElementById('avaa-menu-cat-wrap').hidden=!isCat;document.getElementById('avaa-menu-url-wrap').hidden=isCat;}
    if(e.target.id==='avaa-post-status') S.status=e.target.value;
  });
  root.addEventListener('click', (e) => {if(e.target.id==='avaa-search-trigger'){S.search=document.getElementById('avaa-post-search')?.value||'';renderPosts();}if(e.target.dataset.action==='search-posts'){S.search=document.getElementById('avaa-post-search')?.value||'';S.status=document.getElementById('avaa-post-status')?.value||'any';renderPosts();}});
  // Keep browser/PWA Back inside the app. A normal Back press must never
  // navigate to wp-login.php or perform the explicit WordPress logout action.
  function installBackProtection() {
    const addGuard = () => { try { history.pushState({ avaaBackGuard: true }, '', location.href); } catch (_) {} };
    addGuard();
    window.addEventListener('popstate', () => {
      if (appMenuOpen) setAppMenu(false);
      addGuard();
    });
    window.AVAAHandleBack = function () {
      if (appMenuOpen) { setAppMenu(false); return 'menu-closed'; }
      return 'stay-in-app';
    };
  }
  installBackProtection();
  document.addEventListener('keydown', (event) => { if (event.key === 'Escape' && appMenuOpen) setAppMenu(false); });
  window.addEventListener('unhandledrejection', (event) => { if (event && event.reason) toast(pashtoError(event.reason), true); });
  window.addEventListener('error', (event) => { if (event && event.message) toast(pashtoError(event.message), true); });
  window.addEventListener('beforeinstallprompt', (event) => { event.preventDefault(); window.AVAAInstallPrompt=event; });
  render();
})();
