<?php
if (!defined('ABSPATH')) { exit; }

class AVAA_REST {
    public static function init() { add_action('rest_api_init', array(__CLASS__, 'register_routes')); }

    private static function permission($cap = 'edit_posts') {
        return function () use ($cap) {
            return is_user_logged_in() && current_user_can($cap);
        };
    }

    private static function response($data, $status = 200) {
        return new WP_REST_Response($data, $status);
    }

    private static function safe_array($value) {
        return is_array($value) ? array_values($value) : array();
    }

    private static function clean_text($value, $max = 250) {
        $text = is_scalar($value) ? sanitize_text_field((string) $value) : '';
        return function_exists('mb_substr') ? mb_substr($text, 0, $max) : substr($text, 0, $max);
    }

    private static function theme_settings_keys() {
        return array(
            'radio_title' => 'text', 'radio_url' => 'url_https', 'weekly_title' => 'text', 'weekly_url' => 'url', 'weekly_cover' => 'url',
            'weather_city' => 'text', 'weather_lat' => 'lat', 'weather_lon' => 'lon', 'weather_enabled' => 'bool',
            'facebook_url' => 'url', 'x_url' => 'url', 'youtube_url' => 'url', 'instagram_url' => 'url', 'telegram_url' => 'url',
            'auto_translate' => 'bool', 'hijri_adjust' => 'int', 'footer_about' => 'text', 'footer_note' => 'text',
            'usd_buy' => 'number', 'usd_sell' => 'number', 'eur_buy' => 'number', 'eur_sell' => 'number',
            'pkr_buy' => 'number', 'pkr_sell' => 'number', 'sar_buy' => 'number', 'sar_sell' => 'number', 'aed_buy' => 'number', 'aed_sell' => 'number',
        );
    }

    public static function register_routes() {
        register_rest_route('afghanvoice/v1', '/dashboard', array('methods' => 'GET', 'callback' => array(__CLASS__, 'dashboard'), 'permission_callback' => self::permission('edit_posts')));
        register_rest_route('afghanvoice/v1', '/posts', array(
            array('methods' => 'GET', 'callback' => array(__CLASS__, 'posts'), 'permission_callback' => self::permission('edit_posts')),
            array('methods' => 'POST', 'callback' => array(__CLASS__, 'save_post'), 'permission_callback' => self::permission('edit_posts')),
        ));
        register_rest_route('afghanvoice/v1', '/posts/(?P<id>\d+)', array(
            array('methods' => 'GET', 'callback' => array(__CLASS__, 'get_post'), 'permission_callback' => self::permission('edit_posts')),
            array('methods' => array('POST','PUT','PATCH'), 'callback' => array(__CLASS__, 'save_post'), 'permission_callback' => self::permission('edit_posts')),
            array('methods' => 'DELETE', 'callback' => array(__CLASS__, 'delete_post'), 'permission_callback' => self::permission('delete_posts')),
        ));
        register_rest_route('afghanvoice/v1', '/upload', array('methods' => 'POST', 'callback' => array(__CLASS__, 'upload'), 'permission_callback' => self::permission('upload_files')));
        register_rest_route('afghanvoice/v1', '/media/(?P<id>\d+)', array('methods' => 'DELETE', 'callback' => array(__CLASS__, 'delete_media'), 'permission_callback' => self::permission('upload_files')));
        register_rest_route('afghanvoice/v1', '/categories', array(
            array('methods' => 'GET', 'callback' => array(__CLASS__, 'categories'), 'permission_callback' => self::permission('edit_posts')),
            array('methods' => 'POST', 'callback' => array(__CLASS__, 'save_category'), 'permission_callback' => self::permission('manage_categories')),
        ));
        register_rest_route('afghanvoice/v1', '/categories/(?P<id>\d+)', array(
            array('methods' => array('POST','PUT','PATCH'), 'callback' => array(__CLASS__, 'save_category'), 'permission_callback' => self::permission('manage_categories')),
            array('methods' => 'DELETE', 'callback' => array(__CLASS__, 'delete_category'), 'permission_callback' => self::permission('manage_categories')),
        ));
        register_rest_route('afghanvoice/v1', '/users', array(
            array('methods' => 'GET', 'callback' => array(__CLASS__, 'users'), 'permission_callback' => self::permission('list_users')),
            array('methods' => 'POST', 'callback' => array(__CLASS__, 'save_user'), 'permission_callback' => self::permission('create_users')),
        ));
        register_rest_route('afghanvoice/v1', '/users/(?P<id>\d+)', array(
            array('methods' => array('POST','PUT','PATCH'), 'callback' => array(__CLASS__, 'save_user'), 'permission_callback' => self::permission('edit_users')),
            array('methods' => 'DELETE', 'callback' => array(__CLASS__, 'delete_user'), 'permission_callback' => self::permission('delete_users')),
        ));
        register_rest_route('afghanvoice/v1', '/menus', array(
            array('methods' => 'GET', 'callback' => array(__CLASS__, 'menus'), 'permission_callback' => self::permission('edit_theme_options')),
            array('methods' => 'POST', 'callback' => array(__CLASS__, 'save_menu'), 'permission_callback' => self::permission('edit_theme_options')),
        ));
        register_rest_route('afghanvoice/v1', '/menus/(?P<id>\d+)', array(
            array('methods' => array('POST','PUT','PATCH'), 'callback' => array(__CLASS__, 'save_menu'), 'permission_callback' => self::permission('edit_theme_options')),
            array('methods' => 'DELETE', 'callback' => array(__CLASS__, 'delete_menu'), 'permission_callback' => self::permission('edit_theme_options')),
        ));
        register_rest_route('afghanvoice/v1', '/menu-items', array('methods' => 'POST', 'callback' => array(__CLASS__, 'save_menu_item'), 'permission_callback' => self::permission('edit_theme_options')));
        register_rest_route('afghanvoice/v1', '/menu-items/(?P<id>\d+)', array(
            array('methods' => array('POST','PUT','PATCH'), 'callback' => array(__CLASS__, 'save_menu_item'), 'permission_callback' => self::permission('edit_theme_options')),
            array('methods' => 'DELETE', 'callback' => array(__CLASS__, 'delete_menu_item'), 'permission_callback' => self::permission('edit_theme_options')),
        ));
        register_rest_route('afghanvoice/v1', '/comments', array('methods' => 'GET', 'callback' => array(__CLASS__, 'comments'), 'permission_callback' => self::permission('moderate_comments')));
        register_rest_route('afghanvoice/v1', '/comments/(?P<id>\d+)', array(
            array('methods' => array('POST','PATCH'), 'callback' => array(__CLASS__, 'update_comment'), 'permission_callback' => self::permission('moderate_comments')),
            array('methods' => 'DELETE', 'callback' => array(__CLASS__, 'delete_comment'), 'permission_callback' => self::permission('moderate_comments')),
        ));
        register_rest_route('afghanvoice/v1', '/branding', array('methods' => 'POST', 'callback' => array(__CLASS__, 'set_branding'), 'permission_callback' => self::permission('edit_theme_options')));
        register_rest_route('afghanvoice/v1', '/settings', array(
            array('methods' => 'GET', 'callback' => array(__CLASS__, 'settings'), 'permission_callback' => self::permission('edit_theme_options')),
            array('methods' => array('POST','PUT','PATCH'), 'callback' => array(__CLASS__, 'save_settings'), 'permission_callback' => self::permission('edit_theme_options')),
        ));
    }

    public static function dashboard() {
        $post_counts = wp_count_posts('post');
        $comment_counts = wp_count_comments();
        $cats = get_terms(array('taxonomy' => 'category', 'hide_empty' => false, 'fields' => 'count'));
        $users = current_user_can('list_users') ? count_users() : array('total_users' => 0);
        $recent_result = self::post_query(array('per_page' => 6, 'page' => 1, 'status' => 'any'));
        $recent = is_array($recent_result) && isset($recent_result['items']) ? self::safe_array($recent_result['items']) : array();
        return self::response(array(
            'site' => get_bloginfo('name'), 'user' => wp_get_current_user()->display_name,
            'posts' => array('published' => (int) ($post_counts->publish ?? 0), 'draft' => (int) ($post_counts->draft ?? 0), 'pending' => (int) ($post_counts->pending ?? 0), 'private' => (int) ($post_counts->private ?? 0)),
            'comments' => array('moderated' => (int) ($comment_counts->moderated ?? 0), 'approved' => (int) ($comment_counts->approved ?? 0), 'spam' => (int) ($comment_counts->spam ?? 0)),
            'categories' => is_wp_error($cats) ? 0 : (int) $cats, 'users' => isset($users['total_users']) ? (int) $users['total_users'] : 0,
            'recent' => $recent,
        ));
    }

    private static function post_query($args) {
        $per_page = isset($args['per_page']) ? max(1, min(50, absint($args['per_page']))) : 20;
        $page = isset($args['page']) ? max(1, absint($args['page'])) : 1;
        $status = isset($args['status']) ? sanitize_key($args['status']) : 'any';
        $allowed = array('publish', 'draft', 'pending', 'private', 'future', 'trash', 'any');
        if (!in_array($status, $allowed, true)) $status = 'any';
        $query_args = array(
            'post_type' => 'post', 'post_status' => $status, 'posts_per_page' => $per_page, 'paged' => $page,
            's' => isset($args['search']) ? sanitize_text_field($args['search']) : '',
            'cat' => isset($args['category']) ? absint($args['category']) : 0,
            'orderby' => 'date', 'order' => 'DESC', 'ignore_sticky_posts' => true,
        );
        if (!current_user_can('edit_others_posts')) $query_args['author'] = get_current_user_id();
        $query = new WP_Query($query_args);
        $items = array();
        foreach (self::safe_array($query->posts ?? array()) as $post) { if ($post instanceof WP_Post) $items[] = self::format_post($post); }
        return array('items' => $items, 'total' => (int) $query->found_posts, 'pages' => (int) $query->max_num_pages, 'page' => $page);
    }

    public static function posts($request) { return self::response(self::post_query($request->get_params())); }

    private static function format_post($post) {
        $cats = wp_get_post_categories($post->ID, array('fields' => 'all'));
        $category = array();
        foreach (self::safe_array($cats) as $cat) { if (is_object($cat) && isset($cat->term_id)) $category[] = array('id' => (int) $cat->term_id, 'name' => (string) ($cat->name ?? '')); }
        $thumb = get_post_thumbnail_id($post->ID);
        return array(
            'id' => (int) $post->ID, 'title' => get_the_title($post), 'content' => $post->post_content,
            'excerpt' => get_the_excerpt($post), 'status' => $post->post_status, 'date' => mysql2date('Y-m-d H:i', $post->post_date),
            'author' => get_the_author_meta('display_name', $post->post_author), 'url' => get_permalink($post),
            'categories' => $category, 'featured_image' => $thumb ? wp_get_attachment_image_url($thumb, 'medium') : '', 'thumbnail_id' => $thumb,
            'featured' => get_post_meta($post->ID, '_khabarpaja_featured', true) === '1',
            'breaking' => get_post_meta($post->ID, '_khabarpaja_breaking', true) === '1',
            'video' => (string) get_post_meta($post->ID, '_khabarpaja_video', true),
            'can_edit' => current_user_can('edit_post', $post->ID), 'can_delete' => current_user_can('delete_post', $post->ID),
        );
    }

    public static function get_post($request) {
        $post = get_post(absint($request['id']));
        if (!$post || $post->post_type !== 'post' || !current_user_can('edit_post', $post->ID)) return new WP_Error('not_found', 'خبر ونه موندل شو یا د سمون اجازه نه لرئ.', array('status' => 404));
        return self::response(self::format_post($post));
    }

    public static function save_post($request) {
        $id = absint($request->get_param('id'));
        if ($id && (!get_post($id) || !current_user_can('edit_post', $id))) return new WP_Error('forbidden', 'د دې خبر د سمون اجازه نه لرئ.', array('status' => 403));
        $title = self::clean_text($request->get_param('title'), 250);
        $content = wp_kses_post((string) $request->get_param('content'));
        if ($title === '' || trim(wp_strip_all_tags($content)) === '') return new WP_Error('missing_fields', 'د خبر سرلیک او متن اړین دي.', array('status' => 400));
        $status = sanitize_key((string) $request->get_param('status'));
        if (!in_array($status, array('publish', 'draft', 'pending', 'private'), true)) $status = 'draft';
        $requires_approval = false;
        if ($status === 'publish' && !current_user_can('publish_posts')) { $status = 'pending'; $requires_approval = true; }
        if ($status === 'private' && !current_user_can('publish_posts')) $status = 'draft';
        $category = absint($request->get_param('category'));
        if ($category && !term_exists($category, 'category')) return new WP_Error('bad_category', 'ټاکل شوې کټګوري ونه موندل شوه.', array('status' => 400));
        $postarr = array('post_type' => 'post', 'post_title' => $title, 'post_content' => $content, 'post_status' => $status);
        if ($id) $postarr['ID'] = $id;
        if ($category) $postarr['post_category'] = array($category);
        $post_id = wp_insert_post(wp_slash($postarr), true);
        if (is_wp_error($post_id)) return $post_id;
        if (!$post_id) return new WP_Error('post_save_failed', 'خبر خوندي نه شو؛ مهرباني وکړئ ټول معلومات وګورئ او بیا هڅه وکړئ.', array('status' => 500));
        $saved_post = get_post($post_id);
        if (!$saved_post || $saved_post->post_type !== 'post') return new WP_Error('post_save_failed', 'خبر ثبت نه شو؛ له مدیر سره اړیکه ونیسئ.', array('status' => 500));
        foreach (array('featured' => '_khabarpaja_featured', 'breaking' => '_khabarpaja_breaking') as $field => $meta) {
            if (rest_sanitize_boolean($request->get_param($field))) update_post_meta($post_id, $meta, '1'); else delete_post_meta($post_id, $meta);
        }
        $video = esc_url_raw((string) $request->get_param('video'), array('http', 'https'));
        if ($video) update_post_meta($post_id, '_khabarpaja_video', $video); else delete_post_meta($post_id, '_khabarpaja_video');
        $thumbnail = absint($request->get_param('thumbnail_id'));
        if ($thumbnail && get_post_type($thumbnail) === 'attachment' && current_user_can('upload_files')) set_post_thumbnail($post_id, $thumbnail);
        if ($requires_approval) {
            $message = 'خبر ثبت شو، خو ستاسې حساب د مستقیم خپرولو اجازه نه لري؛ خبر د مدیر تایید ته ولېږل شو.';
        } elseif ($status === 'publish') {
            $message = $id ? 'خبر اصلاح او خپور شو.' : 'خبر په بریالیتوب خپور شو.';
        } elseif ($status === 'pending') {
            $message = 'خبر د مدیر تایید ته ولېږل شو.';
        } elseif ($status === 'private') {
            $message = 'خبر په شخصي حالت کې خوندي شو.';
        } else {
            $message = 'خبر د مسودې په توګه خوندي شو.';
        }
        return self::response(array('message' => $message, 'status' => $status, 'requires_approval' => $requires_approval, 'post' => self::format_post($saved_post)), $id ? 200 : 201);
    }

    public static function delete_post($request) {
        $id = absint($request['id']);
        if (!current_user_can('delete_post', $id)) return new WP_Error('forbidden', 'د دې خبر د حذف اجازه نه لرئ.', array('status' => 403));
        $result = wp_trash_post($id);
        return $result ? self::response(array('message' => 'خبر حذف شو.')) : new WP_Error('delete_failed', 'خبر حذف نه شو.', array('status' => 500));
    }

    public static function upload($request) {
        if (empty($_FILES['file']) || !is_array($_FILES['file'])) return new WP_Error('missing_file', 'فایل وټاکئ.', array('status' => 400));
        $file = $_FILES['file'];
        if (!isset($file['error']) || (int) $file['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($file['tmp_name'])) return new WP_Error('upload_failed', 'فایل پورته نه شو.', array('status' => 400));
        if ((int) $file['size'] <= 0 || (int) $file['size'] > 10 * 1024 * 1024) return new WP_Error('file_size', 'د فایل اندازه باید تر ۱۰ MB کمه وي.', array('status' => 413));
        require_once ABSPATH . 'wp-admin/includes/file.php'; require_once ABSPATH . 'wp-admin/includes/image.php'; require_once ABSPATH . 'wp-admin/includes/media.php';
        $type = wp_check_filetype_and_ext($file['tmp_name'], sanitize_file_name($file['name']));
        if (empty($type['type']) || strpos($type['type'], 'image/') !== 0) return new WP_Error('file_type', 'یوازې د انځور فایلونه پورته کېدای شي؛ ویډیو د لینک له لارې ثبت کړئ.', array('status' => 415));
        $id = media_handle_upload('file', 0);
        if (is_wp_error($id)) return $id;
        return self::response(array('id' => (int) $id, 'url' => wp_get_attachment_image_url($id, 'large'), 'title' => get_the_title($id)), 201);
    }


    public static function delete_media($request) {
        $id = absint($request['id']);
        if (get_post_type($id) !== 'attachment' || !current_user_can('delete_post', $id)) return new WP_Error('forbidden', 'د دې فایل د حذف اجازه نه لرئ.', array('status' => 403));
        $result = wp_delete_attachment($id, true);
        return $result ? self::response(array('message' => 'فایل حذف شو.')) : new WP_Error('delete_failed', 'فایل حذف نه شو.', array('status' => 500));
    }

    public static function categories() {
        $terms = get_terms(array('taxonomy' => 'category', 'hide_empty' => false, 'orderby' => 'name', 'order' => 'ASC'));
        if (is_wp_error($terms) || !is_array($terms)) return self::response(array());
        $items = array(); foreach ($terms as $term) { if (is_object($term)) $items[] = array('id' => (int) $term->term_id, 'name' => (string) $term->name, 'slug' => (string) $term->slug, 'parent' => (int) $term->parent, 'count' => (int) $term->count, 'link' => get_category_link($term)); }
        return self::response($items);
    }

    public static function save_category($request) {
        $id = absint($request['id'] ?? 0); $name = self::clean_text($request->get_param('name'), 120);
        if ($name === '') return new WP_Error('missing_name', 'د کټګورۍ نوم ولیکئ.', array('status' => 400));
        $args = array('slug' => sanitize_title((string) $request->get_param('slug')), 'parent' => absint($request->get_param('parent')));
        if ($id) $result = wp_update_term($id, 'category', array_merge($args, array('name' => $name)));
        else $result = wp_insert_term($name, 'category', $args);
        if (is_wp_error($result)) return $result;
        $term = get_term((int) $result['term_id'], 'category');
        return self::response(array('id' => (int) $term->term_id, 'name' => $term->name, 'slug' => $term->slug, 'parent' => (int) $term->parent), $id ? 200 : 201);
    }

    public static function delete_category($request) {
        $id = absint($request['id']);
        if (!term_exists($id, 'category')) return new WP_Error('not_found', 'کټګوري ونه موندل شوه.', array('status' => 404));
        $uncat = (int) get_option('default_category'); if ($id === $uncat) return new WP_Error('default_category', 'اصلي کټګوري نه شي حذف کېدای.', array('status' => 400));
        $result = wp_delete_term($id, 'category');
        return is_wp_error($result) ? $result : self::response(array('message' => 'کټګوري حذف شوه.'));
    }

    public static function users() {
        $users = get_users(array('number' => 100, 'orderby' => 'registered', 'order' => 'DESC', 'fields' => array('ID', 'user_login', 'display_name', 'user_email', 'user_registered')));
        $items = array(); foreach (self::safe_array($users) as $user) {
            $obj = get_userdata($user->ID);
            $items[] = array('id' => (int) $user->ID, 'username' => $user->user_login, 'name' => $user->display_name, 'email' => $user->user_email, 'registered' => $user->user_registered, 'roles' => $obj ? array_values($obj->roles) : array());
        }
        return self::response(array('items' => $items, 'roles' => self::available_roles()));
    }

    private static function available_roles() {
        $roles_object = wp_roles(); $all = ($roles_object && isset($roles_object->roles) && is_array($roles_object->roles)) ? $roles_object->roles : array(); $roles = array();
        foreach ($all as $key => $role) { if (is_array($role) && isset($role['name'])) $roles[] = array('key' => (string) $key, 'name' => translate_user_role($role['name'])); }
        return $roles;
    }

    public static function save_user($request) {
        $id = absint($request['id'] ?? 0); $name = self::clean_text($request->get_param('name'), 100);
        $email = sanitize_email((string) $request->get_param('email')); $role = sanitize_key((string) $request->get_param('role'));
        $all_roles = array_keys(wp_roles()->roles);
        if ($role && !in_array($role, $all_roles, true)) return new WP_Error('bad_role', 'ټاکل شوی رول ناسم دی.', array('status' => 400));
        if ($role && !current_user_can('promote_users')) return new WP_Error('role_forbidden', 'د کارنانو د رول بدلولو اجازه نه لرئ.', array('status' => 403));
        if ($id) {
            $target = get_userdata($id); if (!$target || !current_user_can('edit_user', $id)) return new WP_Error('forbidden', 'د دې کارن د سمون اجازه نه لرئ.', array('status' => 403));
            $data = array('ID' => $id);
            if ($name !== '') $data['display_name'] = $name;
            if ($email && is_email($email)) $data['user_email'] = $email;
            if ($request->get_param('password')) { $new_password=(string)$request->get_param('password'); if (strlen($new_password)<12) return new WP_Error('weak_password', 'نوی پټنوم باید لږ تر لږه ۱۲ توري ولري.', array('status'=>400)); $data['user_pass']=$new_password; }
            $updated = wp_update_user($data); if (is_wp_error($updated)) return $updated;
            if ($role) { $u = new WP_User($id); $u->set_role($role); }
            return self::response(array('message' => 'د کارن معلومات اصلاح شول.'));
        }
        $username = sanitize_user((string) $request->get_param('username'), true); $password = (string) $request->get_param('password');
        if (!$username || !$email || !is_email($email) || strlen($password) < 12) return new WP_Error('user_fields', 'د کارن نوم، سم ایمیل او لږ تر لږه ۱۲ توري پټنوم اړین دي.', array('status' => 400));
        if (username_exists($username) || email_exists($email)) return new WP_Error('user_exists', 'دا کارن نوم یا ایمیل له مخکې شته.', array('status' => 409));
        if ($role && !current_user_can('promote_users')) return new WP_Error('role_forbidden', 'د کارن رول ټاکلو اجازه نه لرئ.', array('status' => 403));
        $new_id = wp_insert_user(array('user_login' => $username, 'user_pass' => $password, 'user_email' => $email, 'display_name' => $name ?: $username, 'role' => $role ?: get_option('default_role')));
        if (is_wp_error($new_id)) return $new_id;
        return self::response(array('id' => (int) $new_id, 'message' => 'نوی کارن جوړ شو.'), 201);
    }

    public static function delete_user($request) {
        $id = absint($request['id']);
        if ($id === get_current_user_id()) return new WP_Error('self_delete', 'تاسې خپل اوسنی حساب نه شئ حذفولای.', array('status' => 400));
        if (!current_user_can('delete_user', $id)) return new WP_Error('forbidden', 'د دې کارن د حذف اجازه نه لرئ.', array('status' => 403));
        require_once ABSPATH . 'wp-admin/includes/user.php';
        $result = wp_delete_user($id, get_current_user_id());
        return $result ? self::response(array('message' => 'کارن حذف شو.')) : new WP_Error('delete_failed', 'کارن حذف نه شو.', array('status' => 500));
    }

    public static function menus() {
        $menus = wp_get_nav_menus(); $menus = is_array($menus) ? $menus : array(); $locations = get_nav_menu_locations(); $locations = is_array($locations) ? $locations : array(); $registered = get_registered_nav_menus(); $registered = is_array($registered) ? $registered : array(); $items = array();
        foreach ($menus as $menu) {
            if (!is_object($menu) || !isset($menu->term_id)) continue;
            $menu_items = wp_get_nav_menu_items($menu->term_id); $clean_items = array();
            foreach (self::safe_array($menu_items) as $item) { if (is_object($item)) $clean_items[] = array('id' => (int) $item->ID, 'title' => (string) $item->title, 'url' => (string) $item->url, 'type' => ($item->type === 'taxonomy' && $item->object === 'category') ? 'category' : 'custom', 'object' => (string) $item->object, 'object_id' => (int) $item->object_id, 'parent' => (int) $item->menu_item_parent, 'order' => (int) $item->menu_order); }
            $assigned = array(); foreach ($locations as $location => $menu_id) if ((int) $menu_id === (int) $menu->term_id) $assigned[] = $location;
            $items[] = array('id' => (int) $menu->term_id, 'name' => $menu->name, 'items' => $clean_items, 'locations' => $assigned);
        }
        return self::response(array('items' => $items, 'locations' => $registered, 'assigned' => $locations));
    }

    public static function save_menu($request) {
        $id = absint($request['id'] ?? 0); $name = self::clean_text($request->get_param('name'), 100);
        if ($id) {
            $result = wp_update_term($id, 'nav_menu', array('name' => $name ?: 'اصلي مینو'));
            if (is_wp_error($result)) return $result;
            $menu_id = $id;
        } else {
            if ($name === '') return new WP_Error('menu_name', 'د مینو نوم ولیکئ.', array('status' => 400));
            $menu_id = wp_create_nav_menu($name); if (is_wp_error($menu_id)) return $menu_id;
        }
        $location = sanitize_key((string) $request->get_param('location'));
        if ($location && isset(get_registered_nav_menus()[$location])) {
            $locations = get_nav_menu_locations(); $locations[$location] = $menu_id; set_theme_mod('nav_menu_locations', $locations);
        }
        return self::response(array('id' => (int) $menu_id, 'message' => 'مینو خوندي شو.'), $id ? 200 : 201);
    }

    public static function delete_menu($request) {
        $id = absint($request['id']); $result = wp_delete_nav_menu($id);
        return is_wp_error($result) ? $result : self::response(array('message' => 'مینو حذف شو.'));
    }

    public static function save_menu_item($request) {
        $menu_id = absint($request->get_param('menu_id')); $item_id = absint($request['id'] ?? 0);
        if (!$menu_id || !wp_get_nav_menu_object($menu_id)) return new WP_Error('menu_missing', 'مینو وټاکئ.', array('status' => 400));
        $menu_existing = wp_get_nav_menu_items($menu_id);
        $allowed_item_ids = array_map('intval', wp_list_pluck((array) $menu_existing, 'ID'));
        if ($item_id && !in_array($item_id, $allowed_item_ids, true)) return new WP_Error('bad_item', 'د مینو توکی په دې مینو کې نشته.', array('status' => 400));
        $title = self::clean_text($request->get_param('title'), 120); $type = sanitize_key((string) $request->get_param('type'));
        $parent_id = absint($request->get_param('parent'));
        if ($parent_id) { $parent_post = get_post($parent_id); $allowed_parent_ids = $allowed_item_ids; if ($parent_id === $item_id || !$parent_post || $parent_post->post_type !== 'nav_menu_item' || !in_array($parent_id, $allowed_parent_ids, true)) return new WP_Error('bad_parent', 'د والد مینو توکی سم نه دی.', array('status' => 400)); }
        $args = array('menu-item-title' => $title, 'menu-item-status' => 'publish', 'menu-item-position' => absint($request->get_param('position')) ?: 0, 'menu-item-parent-id' => $parent_id);
        if ($type === 'category') {
            $term_id = absint($request->get_param('object_id')); if (!term_exists($term_id, 'category')) return new WP_Error('category_missing', 'کټګوري ونه موندل شوه.', array('status' => 400));
            $args['menu-item-type'] = 'taxonomy'; $args['menu-item-object'] = 'category'; $args['menu-item-object-id'] = $term_id;
        } else {
            $url = esc_url_raw((string) $request->get_param('url'), array('http', 'https'));
            if (!$url) return new WP_Error('url_missing', 'سم لینک ولیکئ.', array('status' => 400));
            $args['menu-item-type'] = 'custom'; $args['menu-item-url'] = $url;
        }
        $saved = wp_update_nav_menu_item($menu_id, $item_id, $args);
        if (is_wp_error($saved)) return $saved;
        return self::response(array('id' => (int) $saved, 'message' => 'د مینو توکی اضافه/اصلاح شو.'), $item_id ? 200 : 201);
    }

    public static function delete_menu_item($request) {
        $id = absint($request['id']);
        if (get_post_type($id) !== 'nav_menu_item') return new WP_Error('invalid_item', 'دا د مینو توکی نه دی.', array('status' => 400));
        $result = wp_delete_post($id, true);
        return $result ? self::response(array('message' => 'د مینو توکی حذف شو.')) : new WP_Error('delete_failed', 'د مینو توکی حذف نه شو.', array('status' => 500));
    }

    public static function comments($request) {
        $status = sanitize_key((string) $request->get_param('status')); $allowed = array('hold', 'approve', 'spam', 'trash', 'all'); if (!in_array($status, $allowed, true)) $status = 'hold';
        $args = array('number' => 50, 'orderby' => 'comment_date_gmt', 'order' => 'DESC'); if ($status !== 'all') $args['status'] = $status;
        $comments = get_comments($args); $items = array();
        foreach (self::safe_array($comments) as $c) { if (is_object($c)) $items[] = array('id' => (int) $c->comment_ID, 'author' => (string) $c->comment_author, 'email' => (string) $c->comment_author_email, 'content' => (string) $c->comment_content, 'date' => (string) $c->comment_date, 'status' => (string) $c->comment_approved, 'post' => (string) get_the_title($c->comment_post_ID)); }
        return self::response($items);
    }

    public static function update_comment($request) {
        $id = absint($request['id']); $status = sanitize_key((string) $request->get_param('status'));
        if (!in_array($status, array('approve', 'hold', 'spam', 'trash'), true)) return new WP_Error('bad_status', 'د نظر حالت ناسم دی.', array('status' => 400));
        $ok = wp_set_comment_status($id, $status);
        return is_wp_error($ok) ? $ok : self::response(array('message' => 'د نظر حالت بدل شو.'));
    }

    public static function delete_comment($request) {
        $result = wp_delete_comment(absint($request['id']), true);
        return $result ? self::response(array('message' => 'نظر حذف شو.')) : new WP_Error('delete_failed', 'نظر حذف نه شو.', array('status' => 500));
    }


    public static function set_branding($request) {
        $id = absint($request->get_param('attachment_id'));
        if (!$id || get_post_type($id) !== 'attachment' || !wp_attachment_is_image($id)) return new WP_Error('invalid_logo', 'د لوګو لپاره سم انځور وټاکئ.', array('status' => 400));
        set_theme_mod('custom_logo', $id);
        return self::response(array('message' => 'د وېب‌پاڼې لوګو بدل شو.', 'logo' => wp_get_attachment_image_url($id, 'full')));
    }

    public static function settings() {
        $all = get_option('khabarpaja_settings', array()); if (!is_array($all)) $all = array();
        $out = array(); foreach (self::theme_settings_keys() as $key => $type) $out[$key] = isset($all[$key]) ? $all[$key] : '';
        $out['site_title'] = get_option('blogname'); $out['site_description'] = get_option('blogdescription');
        $out['home_sections'] = get_option('khabarpaja_home_sections', array());
        if (!is_array($out['home_sections'])) $out['home_sections'] = array();
        $out['menu_mode'] = get_option('khabarpaja_menu_mode', 'auto');
        $out['menu_categories'] = get_option('khabarpaja_menu_categories', array());
        if (!is_array($out['menu_categories'])) $out['menu_categories'] = array();
        $out['currency_updated'] = isset($all['currency_updated']) ? (int) $all['currency_updated'] : 0;
        $out['custom_logo'] = (int) get_theme_mod('custom_logo', 0);
        $out['categories'] = get_terms(array('taxonomy' => 'category', 'hide_empty' => false, 'fields' => 'all'));
        if (is_wp_error($out['categories']) || !is_array($out['categories'])) $out['categories'] = array();
        $out['categories'] = array_map(function($t){return array('id'=>(int)$t->term_id,'name'=>$t->name);}, $out['categories']);
        return self::response($out);
    }

    public static function save_settings($request) {
        $old = get_option('khabarpaja_settings', array()); if (!is_array($old)) $old = array(); $new = $old;
        $input = $request->get_json_params(); if (!is_array($input)) $input = array();
        foreach (self::theme_settings_keys() as $key => $type) {
            if (!array_key_exists($key, $input)) continue;
            $value = $input[$key];
            switch ($type) {
                case 'bool': $new[$key] = rest_sanitize_boolean($value) ? '1' : '0'; break;
                case 'int': $new[$key] = (string) max(-2, min(2, (int) $value)); break;
                case 'lat': $new[$key] = is_numeric($value) && (float)$value >= -90 && (float)$value <= 90 ? (string)(float)$value : ''; break;
                case 'lon': $new[$key] = is_numeric($value) && (float)$value >= -180 && (float)$value <= 180 ? (string)(float)$value : ''; break;
                case 'number': $number = preg_replace('/[^0-9.,\-]/', '', (string)$value); $new[$key] = substr($number, 0, 20); break;
                case 'url_https': $new[$key] = esc_url_raw((string)$value, array('https')); break;
                case 'url': $new[$key] = esc_url_raw((string)$value, array('http', 'https')); break;
                default: $new[$key] = self::clean_text($value, 500);
            }
        }
        $currency_changed = false;
        foreach (array('usd','eur','pkr','sar','aed') as $currency) foreach (array('buy','sell') as $side) { $k=$currency.'_'.$side; if (isset($new[$k]) && (string)$new[$k] !== (string)($old[$k] ?? '')) $currency_changed=true; }
        if ($currency_changed) $new['currency_updated'] = time();
        update_option('khabarpaja_settings', $new, false);

        if (current_user_can('manage_options')) {
            if (isset($input['site_title'])) update_option('blogname', self::clean_text($input['site_title'], 120));
            if (isset($input['site_description'])) update_option('blogdescription', self::clean_text($input['site_description'], 250));
        }
        if (isset($input['custom_logo']) && current_user_can('edit_theme_options')) { $logo_id=absint($input['custom_logo']); if (!$logo_id || (get_post_type($logo_id)==='attachment' && wp_attachment_is_image($logo_id))) set_theme_mod('custom_logo', $logo_id); }
        if (isset($input['menu_mode']) && current_user_can('edit_theme_options')) update_option('khabarpaja_menu_mode', $input['menu_mode'] === 'wordpress' ? 'wordpress' : 'auto', false);
        if (isset($input['menu_categories']) && is_array($input['menu_categories']) && current_user_can('manage_categories')) {
            $valid = array(); foreach ($input['menu_categories'] as $term_id) { $tid=absint($term_id); if ($tid && term_exists($tid, 'category')) $valid[]=$tid; }
            update_option('khabarpaja_menu_categories', array_values(array_unique($valid)), false);
        }
        if (isset($input['home_sections']) && is_array($input['home_sections']) && current_user_can('edit_others_posts')) {
            $clean = array(); foreach ($input['home_sections'] as $key => $ids) { $key=sanitize_key($key); if (!is_array($ids)) continue; foreach ($ids as $tid) { $tid=absint($tid); if ($tid && term_exists($tid, 'category')) $clean[$key][]=$tid; } }
            update_option('khabarpaja_home_sections', $clean, false);
        }
        return self::response(array('message' => 'تنظیمات خوندي شول.'));
    }
}
