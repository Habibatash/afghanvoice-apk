<?php
if (!defined('ABSPATH')) { exit; }

class AVAA_App {
    public static function init() {
        add_action('admin_menu', array(__CLASS__, 'admin_menu'));
        add_action('admin_notices', array(__CLASS__, 'theme_notice'));
        add_action('wp_ajax_avaa_manifest', array(__CLASS__, 'send_manifest'));
        add_action('wp_ajax_nopriv_avaa_manifest', array(__CLASS__, 'send_manifest'));
        add_action('wp_ajax_avaa_sw', array(__CLASS__, 'send_service_worker'));
        add_action('wp_ajax_nopriv_avaa_sw', array(__CLASS__, 'send_service_worker'));
    }

    public static function activate() {}
    public static function deactivate() {}

    public static function admin_menu() {
        add_menu_page(
            'د افغان غږ اډمین اپ',
            'افغان غږ اپ',
            'edit_posts',
            'afghanvoice-admin-app',
            array(__CLASS__, 'admin_page'),
            'dashicons-smartphone',
            4
        );
    }

    public static function theme_notice() {
        if (!current_user_can('activate_plugins') || !isset($_GET['activate'])) return;
        if (!wp_get_theme()->exists()) return;
        echo '<div class="notice notice-info"><p>د افغان غږ اپ د پرانیستلو لپاره د WordPress له اړخیز مېنو څخه «افغان غږ اپ» وټاکئ، یا <a href="' . esc_url(self::app_url()) . '">د اپ لینک</a> پرانیزئ.</p></div>';
    }

    public static function admin_page() {
        if (!current_user_can('edit_posts')) wp_die(esc_html__('تاسو دې اپ ته د ننوتلو اجازه نه لرئ.'));
        self::render_app();
    }

    public static function dispatch_routes() {
        if (get_query_var('avaa_manifest')) {
            self::send_manifest();
        }
        if (get_query_var('avaa_sw')) {
            self::send_service_worker();
        }
        if (get_query_var('avaa_app')) {
            self::render_app();
        }
    }

    private static function icon_url($size) {
        return AVAA_URL . 'assets/icons/icon-' . absint($size) . '.png';
    }

    public static function app_url() { return admin_url('admin.php?page=afghanvoice-admin-app'); }
    private static function manifest_url() { return admin_url('admin-ajax.php?action=avaa_manifest'); }
    private static function worker_url() { return admin_url('admin-ajax.php?action=avaa_sw'); }

    public static function send_manifest() {
        $manifest = array(
            'id' => self::app_url(),
            'name' => 'د افغان غږ اډمین اپ',
            'short_name' => 'افغان غږ اداره',
            'description' => 'د افغان غږ د WordPress بشپړ مدیریتي اپ',
            'lang' => 'ps', 'dir' => 'rtl', 'start_url' => self::app_url(),
            'scope' => admin_url('/'), 'display' => 'standalone',
            'background_color' => '#f2f5fa', 'theme_color' => '#123b61',
            'icons' => array(
                array('src' => self::icon_url(192), 'sizes' => '192x192', 'type' => 'image/png', 'purpose' => 'any maskable'),
                array('src' => self::icon_url(512), 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'any maskable'),
            ),
        );
        nocache_headers();
        header('Content-Type: application/manifest+json; charset=utf-8');
        echo wp_json_encode($manifest, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    public static function send_service_worker() {
        nocache_headers();
        header('Content-Type: application/javascript; charset=utf-8');
        header('Service-Worker-Allowed: ' . wp_parse_url(admin_url('/'), PHP_URL_PATH));
        $app_url = self::app_url();
        $css = AVAA_URL . 'assets/admin-app.css?ver=' . AVAA_VERSION;
        $js = AVAA_URL . 'assets/admin-app.js?ver=' . AVAA_VERSION;
        $icon = self::icon_url(192);
        echo "const CACHE='avaa-shell-v1.0.0';\n";
        echo 'const SHELL=' . wp_json_encode(array($app_url, $css, $js, $icon)) . ";\n";
        echo "self.addEventListener('install',e=>{e.waitUntil(caches.open(CACHE).then(c=>c.addAll(SHELL)).then(()=>self.skipWaiting()))});\n";
        echo "self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k.startsWith('avaa-shell-')&&k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()))});\n";
        echo "self.addEventListener('fetch',e=>{const u=new URL(e.request.url);if(u.origin!==location.origin)return;if(u.pathname.includes('/wp-json/'))return;if(e.request.method!=='GET')return;if(e.request.mode==='navigate'&&u.pathname.endsWith('/wp-admin/admin.php')&&u.searchParams.get('page')==='afghanvoice-admin-app'){e.respondWith(fetch(e.request).then(r=>{if(r.ok){const copy=r.clone();caches.open(CACHE).then(c=>c.put(" . wp_json_encode($app_url) . ",copy));}return r;}).catch(()=>caches.match(" . wp_json_encode($app_url) . ")));return;}if(SHELL.some(x=>new URL(x).pathname===u.pathname)){e.respondWith(caches.match(e.request).then(hit=>hit||fetch(e.request)));}});\n";
        exit;
    }

    private static function render_app() {
        if (!is_user_logged_in()) {
            $login = wp_login_url(self::app_url());
            wp_safe_redirect($login);
            exit;
        }
        if (!current_user_can('edit_posts')) {
            status_header(403);
            wp_die(esc_html__('تاسو ته د افغان غږ د ادارې اپ د کارولو اجازه نشته.'), esc_html__('د لاسرسي اجازه نشته'), array('response' => 403));
        }
        $logo = '';
        $custom_logo_id = (int) get_theme_mod('custom_logo');
        if ($custom_logo_id) {
            $src = wp_get_attachment_image_src($custom_logo_id, 'full');
            if ($src && !empty($src[0])) $logo = $src[0];
        }
        if (!$logo) {
            $theme_logo = get_template_directory() . '/assets/images/afghanvoice-logo.png';
            if (file_exists($theme_logo)) $logo = get_template_directory_uri() . '/assets/images/afghanvoice-logo.png';
        }
        $config = array(
            'api' => esc_url_raw(rest_url('afghanvoice/v1')),
            'wpApi' => esc_url_raw(rest_url('wp/v2')),
            'nonce' => wp_create_nonce('wp_rest'),
            'home' => esc_url_raw(home_url('/')),
            'app' => esc_url_raw(self::app_url()),
            'logo' => esc_url_raw($logo),
            'user' => array('name' => wp_get_current_user()->display_name, 'id' => get_current_user_id()),
            'canManageUsers' => current_user_can('list_users'),
            'canPromoteUsers' => current_user_can('promote_users'),
            'canManageSite' => current_user_can('manage_options'),
            'defaultRole' => get_option('default_role', 'subscriber'),
            'canManageSettings' => current_user_can('edit_theme_options'),
            'canManageCategories' => current_user_can('manage_categories'),
            'canManageMenus' => current_user_can('edit_theme_options'),
            'canModerateComments' => current_user_can('moderate_comments'),
            'canUpload' => current_user_can('upload_files'),
            'logout' => wp_logout_url(home_url('/wp-login.php')),
            'version' => AVAA_VERSION,
            'labels' => array('loading' => 'مهرباني، لږ انتظار وکړئ...', 'error' => 'ستونزه رامنځته شوه. بیا هڅه وکړئ.', 'saved' => 'بدلونونه خوندي شول.'),
        );
        nocache_headers();
        status_header(200);
        ?><!doctype html>
<html lang="ps" dir="rtl"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#123b61"><meta name="apple-mobile-web-app-capable" content="yes"><meta name="apple-mobile-web-app-status-bar-style" content="black-translucent"><meta name="apple-mobile-web-app-title" content="افغان غږ اداره">
<link rel="manifest" href="<?php echo esc_url(self::manifest_url()); ?>"><link rel="apple-touch-icon" sizes="180x180" href="<?php echo esc_url(AVAA_URL . 'assets/icons/apple-touch-icon.png?ver=' . AVAA_VERSION); ?>">
<link rel="stylesheet" href="<?php echo esc_url(AVAA_URL . 'assets/admin-app.css?ver=' . AVAA_VERSION); ?>">
<link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Noto+Naskh+Arabic:wght@400;500;600;700&family=Vazirmatn:wght@400;500;600;700&display=swap" rel="stylesheet">
<title>د افغان غږ اډمین اپ</title></head><body>
<div id="avaa-app" class="avaa-app"><div class="avaa-loading"><div class="avaa-spinner"></div><p>د افغان غږ اداره پرانیستل کېږي...</p></div></div>
<script>window.AVAA=<?php echo wp_json_encode($config, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;</script>
<script src="<?php echo esc_url(AVAA_URL . 'assets/admin-app.js?ver=' . AVAA_VERSION); ?>" defer></script>
<script>if('serviceWorker' in navigator){window.addEventListener('load',function(){navigator.serviceWorker.register(<?php echo wp_json_encode(self::worker_url()); ?>,{scope:<?php echo wp_json_encode(wp_parse_url(admin_url('/'), PHP_URL_PATH) ?: '/wp-admin/'); ?>}).catch(function(){});});}</script>
</body></html><?php
        exit;
    }
}
