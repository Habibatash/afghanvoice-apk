<?php
/**
 * Plugin Name: Afghan Voice Admin App
 * Description: A secure, Pashto-first cross-platform PWA administration app for the Afghan Voice WordPress site.
 * Version: 1.0.4
 * Requires at least: 7.0
 * Requires PHP: 8.4
 * Author: Afghan Voice
 * Text Domain: afghanvoice-admin-app
 */
if (!defined('ABSPATH')) { exit; }

if (!defined('AVAA_VERSION')) define('AVAA_VERSION', '1.0.4');
if (!defined('AVAA_DIR')) define('AVAA_DIR', plugin_dir_path(__FILE__));
if (!defined('AVAA_URL')) define('AVAA_URL', plugin_dir_url(__FILE__));

require_once AVAA_DIR . 'includes/class-avaa-rest.php';
require_once AVAA_DIR . 'includes/class-avaa-app.php';

register_activation_hook(__FILE__, array('AVAA_App', 'activate'));
register_deactivation_hook(__FILE__, array('AVAA_App', 'deactivate'));
add_action('plugins_loaded', function () {
    AVAA_REST::init();
    AVAA_App::init();
});
